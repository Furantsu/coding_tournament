package tournament1;

public class MAP extends Picture{

	MAP(int w, int h) {
		super(w, h);
	}

	public static void main(String[]args)
	{
		System.out.print("Deliktum");	
	
	}
}
