package tournament1;

public class Color {

	Color(int r, int g, int b){	   	
		
	}
}