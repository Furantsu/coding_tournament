package tournament1;

public class UI extends Color{

	UI(int w, int h) {
		super(w, h, h);
	}
	
	void Color(int r, int g, int b){	   
		
	}	
		
	public static void main (String [] args)
	
	{
				System.out.print("Acciones");	
					System.out.print(" Borrachera");
						System.out.print(" Manifestacion Violenta");
							System.out.print(" Violencia Escolar");
								System.out.print(" Pelea");
									System.out.print(" Robo");
										System.out.print(" Soborno a Policias");
											System.out.print(" Atropellamiento");
												System.out.print(" Vandalismo");
													System.out.print(" Venta de Drogas");
														System.out.print(" Asalto");
															System.out.print(" Asesinato");
	} 
	
	public static void main1 (String [] args) {
				
				System.out.println("Amenza");
	}
	
}

