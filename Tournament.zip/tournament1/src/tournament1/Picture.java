package tournament1;


public class Picture {

		protected static final char[] Color = null;

		Picture(Object w, int h){}
		
			void set(int col, int row,Color color) {
			
			}
		int width() {
			return 1920;
			}
		int height() {
			return 1080;
		}
		void show() {
		System.out.println(Color);
		}
	
}


