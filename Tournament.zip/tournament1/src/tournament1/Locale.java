package tournament1;

public class Locale {

}
