/**
 * 
 */
/**
 * @author Usuario
 *
 */
module tournament1 {
	requires java.datatransfer;
}